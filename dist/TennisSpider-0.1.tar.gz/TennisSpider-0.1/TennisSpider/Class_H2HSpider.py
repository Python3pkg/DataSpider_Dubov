# coding: utf-8

#Настроить внутренние функции, чтобы можно было выбирать, какуб информацию об игроке получать.

import grab
import os
import csv
import sys
import argparse
from grab.spider import Spider, Task

class H2HSpider:
    pass